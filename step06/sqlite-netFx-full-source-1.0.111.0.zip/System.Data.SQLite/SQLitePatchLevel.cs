/********************************************************
 * ADO.NET 2.0 Data Provider for SQLite Version 3.X
 * Written by Joe Mistachkin (joe@mistachkin.com)
 *
 * Released to the public domain, use at your own risk!
 ********************************************************/

using System.Data.SQLite;

///////////////////////////////////////////////////////////////////////////////

[assembly: AssemblySourceId("767b97f17029698d929f3fd9be563f51942b1805")]

///////////////////////////////////////////////////////////////////////////////

[assembly: AssemblySourceTimeStamp("2019-05-16 03:23:41 UTC")]
