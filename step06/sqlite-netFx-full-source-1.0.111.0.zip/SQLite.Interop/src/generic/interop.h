/*
 * interop.h -
 *
 * Written by Joe Mistachkin.
 * Released to the public domain, use at your own risk!
 */

#ifndef INTEROP_VERSION
#define INTEROP_VERSION          "1.0.111.0"
#endif

#ifndef INTEROP_SOURCE_ID
#define INTEROP_SOURCE_ID        "767b97f17029698d929f3fd9be563f51942b1805"
#endif

#ifndef INTEROP_SOURCE_TIMESTAMP
#define INTEROP_SOURCE_TIMESTAMP "2019-05-16 03:23:41 UTC"
#endif
